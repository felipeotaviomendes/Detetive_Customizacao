function verificaVazio(){
	var caso,fase,erro;
	erro=[false, false, false];
	erroLabel=false;

	for(caso=1;caso<4;caso++){
		
		for(fase=1;fase<7;fase++){
			erroLabel=false;
			if(document.getElementById('pergunta'+fase+'_caso'+caso).value == "" || document.getElementById('pergunta'+fase+'_caso'+caso).value.length > 50){
				document.getElementById('pergunta'+fase+'_caso'+caso+'_text').style.color = "#d50000";
				erroLabel=true;
			}
			else document.getElementById('pergunta'+fase+'_caso'+caso+'_text').style.color = "black";

			if(document.getElementById('resposta'+fase+'_caso'+caso).value == "" || document.getElementById('resposta'+fase+'_caso'+caso).value.length > 15){
				document.getElementById('resposta'+fase+'_caso'+caso+'_text').style.color = "#d50000";
				erroLabel=true;
			}
			else document.getElementById('resposta'+fase+'_caso'+caso+'_text').style.color = "black";
			
			if(erroLabel){
				erro[caso-1]=true;
				document.getElementById('caso'+caso+'_etapa'+fase).style.color = "#d50000";
			}else{
				document.getElementById('caso'+caso+'_etapa'+fase).style.color = "black";
			}
		}

		if(document.getElementById('descricao'+caso).value == "" || document.getElementById('descricao'+caso).value.length > 200){
			document.getElementById('descricao'+caso+'_text').style.color = "#d50000";
			erro[caso-1]=true;
		}
		else document.getElementById('descricao'+caso+'_text').style.color = "black";
	}

	if(erro[0]||erro[1]||erro[2]){
		alert('Corrija os campos em vermelho!');
	}
}